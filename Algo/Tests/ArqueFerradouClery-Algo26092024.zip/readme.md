# ESGI@Algo ESGI1 2023/2024

---

# 1/ Objectif

Rappel algorithmie simple
Programme Boucle/Test
Interprétation

# 2/ Todo

Constat: sur 100 naissances il y a 51 garçons/49 filles.
Je suis un tyran à la tête d'un pays, je souhaite augmenter rapidement la population de mon pays:
Je me dis qu'il vaut mieux faire beaucoup de filles, et donc pour chaque famille, j'interdis d'avoir d'autre enfant quand on a 1 garçon, mais j'autorise jusqu'à 4 filles.
Ai-je une bonne idée ou pas? Le prouver!

# 3/ Consignes

- un programme clair qui fait intervenir des variables pertinentes
- une découpe en fonctions logiques
- quelques commentaires
- rajouter en commentaire en fin de progr une explication à la question:
  "Ai-je une bonne idée ou pas?"

- Me remettre une archive htm/js sous la forme NomPrénom-Algo26092024.zip sur pdareys@myges.fr (ou un fichier Python ou encore une feuille expliquant votre raisonnement algorithmique)

# 4/ Résultats attendus

C'est une surprise? ou pas? Expliquer

# 5/ Aide

- il faut prendre un grand nombre de familles et "leur faire avoir des enfants", puis tester le sexe de ces enfants, enfin comptabiliser le tout
- Pour tirer au sort entre 'min' et 'max' compris, on peut utiliser:
  Math.floor(Math.random() \* (max - min + 1)) + min;
