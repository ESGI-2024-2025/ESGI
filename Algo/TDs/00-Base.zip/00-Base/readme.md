# ESGI@Algo ESGI1 2024/2025
# --------------
# 1/ Objectif
- Mettre au point un test d'algo
- Debugger (trace, sortie, log, ...)
- Maîtrise de VScode

# 2/ Todo
Installer le dossier livré
Installer VSCode/LiveServer
Exécuter, débugger, générer une erreur

# 3/ Consignes
 - décommenter le code opérationnel
 - changer le titre
 - lancer index.htm dans vscode
 - debugger le prog en mettant un point d'arrêt dans la méthode main

# 4/ Résultats attendus
Le projet sert de modèle aux autres exercices
